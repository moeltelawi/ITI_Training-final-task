from flask import Flask, render_template, flash, redirect, url_for, session, request, logging
import mysql.connector
from passlib.hash import sha256_crypt
app = Flask(__name__)


@app.route('/')
def index():
    return render_template('home.html')

@app.route('/admin', methods=['GET', 'POST'])
def admin():
    
    if request.method == 'POST':
        x = request.form['username']
        y = request.form['password']
        if x != 'admin' or y != 'admin':
           return redirect(url_for('login'))
        else:
            return redirect(url_for('dashboard'))

    return render_template('admin.html')

@app.route('/dashboard')
def dashboard():
    prod = mysql.connector.connect(
         host="localhost",
         user="root",
         passwd="",
         database="mydb")
    pcur = prod.cursor()
    pcur.execute("SELECT * FROM products")
    products = pcur.fetchall()
    return render_template('dashboard.html', products=products)
    pcur.close()



@app.route('/profile')
def profile():
    return render_template('profile.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    conn = mysql.connector.connect(
         host="localhost",
         user="root",
         passwd="",
         database="mydb")
    
        
    if request.method == 'POST' and 'email' in request.form and 'password' in request.form:
       
        email = request.form['email']
        password = sha256_crypt.encrypt(str(request.form['password']))
       
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM users WHERE email = %s AND password = %s', (email, password))
      
        account = cursor.fetchone()
       
        if account:
           
            session['loggedin'] = True
            session['id'] = account['id']
            session['username'] = account['username']
          
            
            return redirect(url_for('index'))
        else:
            return redirect(url_for('index'))
    return render_template('login.html')
            
    
        
    

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        mydb = mysql.connector.connect(
         host="localhost",
          user="root",
          passwd="",
          database="mydb"
            )
        fname = request.form['fnm']
        lname = request.form['lnm']
        email = request.form['email']
        password = sha256_crypt.encrypt(str(request.form['password']))

        mycursor = mydb.cursor()

        mycursor.execute(
            "INSERT INTO users(fname, lname, email, password) VALUES(%s, %s, %s, %s)", (fname, lname, email, password))


        mydb.commit()
        mydb.close()



        return redirect(url_for('login'))
    return render_template('register.html')

if __name__ == '__main__':
    app.run(debug=True)
